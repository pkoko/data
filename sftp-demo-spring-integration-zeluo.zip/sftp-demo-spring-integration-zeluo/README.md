# spring-boot-sftp

Demo project for Spring Boot with spring-integration-ftp

### how to run

1. copy `application.yml.template` to 'application.yml'
2. config `sftp in application.yml`
3. run `SftpApplication.java`, then visit `127.0.0.1:9001`
4. or run `SftpApplicationTests.class`